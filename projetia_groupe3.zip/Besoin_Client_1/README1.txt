#projet IA Client 3
Projet IA A3

## Lancement script python pour la carte du client 1:
Avec les librairies : pandas, folium, matplotlib, sklearn

## Commandes:
Pour lancer le script, aller dans le fichier "client1.ipynb" 
et lancer la dernière cellule en précisant le nombre_clusters



