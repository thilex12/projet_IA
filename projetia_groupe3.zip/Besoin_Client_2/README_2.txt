#projet IA Client 2
Projet IA A3

# Lancement script python 
Avoir les librairies : pandas, pickle

# Commande :
Pour lancer le script, aller dans le fichier "client2.ipynb". 
Aller sur la derniere cellule (fonction "func_besoin2()"), placer les paramètres des fichiers souhaités: "data.json","res.json"